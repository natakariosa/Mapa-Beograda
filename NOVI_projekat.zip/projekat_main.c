#include "projekat.h"

int main( void )
{
    Graf *G = napravi_graf();
    int i=0;
    
//     for( i = 0 ; i < G->dim ; i++ ) printf( "%ld %lf %lf\n" , G->putevi[i]->id , G->putevi[i]->lat , G->putevi[i]->lon );
    
    
    return( 0 );
}
